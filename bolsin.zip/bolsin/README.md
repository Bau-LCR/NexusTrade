# Bolsín — terminal de trading simulado (HTML + CSS + JS nativo)
**Entorno de simulación: dinero virtual, datos generados artificialmente. No son cotizaciones reales.**

## Publicar en GitHub Pages
1. Subí el contenido de esta carpeta a un repositorio. 2. Settings → Pages → Branch `main`, carpeta `/ (root)`. 3. Listo: no hay compilación.

## Probar en local (los módulos ES necesitan HTTP, no `file://`)
`python3 -m http.server 8000` y abrí http://localhost:8000

## Reglas
- Mercado: 15 activos ficticios, un único timer (1 tick = 1 segundo simulado), movimiento browniano geométrico + reversión a la media + factor común (correlación parcial). Semilla reproducible. Las velas 5s/15s/1m/5m se agregan desde las de 1s.
- Contabilidad: patrimonio = efectivo + Σ cantidad × precio. La comisión de compra se suma al costo medio; realizado = (cantidad × precio − comisión) − costo medio × cantidad. Solo posiciones largas, sin apalancamiento.
- Órdenes: mercado (con deslizamiento) y límite (reservan efectivo o cantidad hasta ejecutarse o cancelarse).
- Persistencia: IndexedDB en este navegador (no se sincroniza y el navegador puede borrarla). Exportá copias JSON desde la barra superior.

## Pendiente / limitaciones
Stop, stop-limit, OCO, ventas en corto, indicadores adicionales (RSI, MACD, Bollinger…), herramientas de dibujo, alertas, libro de órdenes, cartera/estadísticas, laboratorio histórico, atajos y ajustes de tema. No se ejecutó ninguna prueba automatizada.
